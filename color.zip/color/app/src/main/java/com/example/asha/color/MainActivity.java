package com.example.asha.color;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button button,button2,button3;
    EditText edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=(Button)findViewById(R.id.button);
        button2=(Button)findViewById(R.id.button2);
        button3=(Button)findViewById(R.id.button3);
        edit=(EditText)findViewById(R.id.editText);
        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String r=edit.getText().toString();
                String[] items = r.split(",");
                for(int i = 0; i < items.length; i++)
                {
                    if (items[i].equals("RED"))
                    {
                        button.setBackgroundColor(Color.RED);
                    }
                    else
                    {
                        button.setBackgroundColor(Color.GRAY);
                    }
                    if (items[i].equals("GREEN"))
                    {
                        button2.setBackgroundColor(Color.GREEN);
                    }
                    else
                    {
                        button2.setBackgroundColor(Color.GRAY);
                    }
                    if (items[i].equals("BLUE"))
                    {
                        button3.setBackgroundColor(Color.BLUE);
                    }
                    else
                    {
                        button3.setBackgroundColor(Color.GRAY);
                    }
                }
            }
        });


    }
}
