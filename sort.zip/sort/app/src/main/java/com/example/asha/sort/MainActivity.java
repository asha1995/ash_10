package com.example.asha.sort;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Spannable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btn;
    TextView text;
    EditText edit;
    int num[]=new int[100];
    int i,n,j;
    int temp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=(Button)findViewById(R.id.button);
        text=(TextView)findViewById(R.id.textView2);
        edit=(EditText)findViewById(R.id.editText);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BubbleSort();

            }
        });
    }

    public void BubbleSort() {

        Spannable spn=edit.getText();
        for (int i = 0; i < spn.length(); i++)
        {
            num[i] = Integer.parseInt(""+spn.charAt(i));
        }

        for (i = 0; i < num.length; i++) {
            for(j = i+1; j < num.length; j++) {
                if (num[i] > num[j]) {
                    temp = num[i];
                    num[i] = num[j];
                    num[j] = temp;
                }
            }
        }

        String result= "";
        for (int i = 0; i < spn.length(); i++) {
            result += num[i];
        }
        text.setText(result);
    }
}
